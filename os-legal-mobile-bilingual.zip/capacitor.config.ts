import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ae.oslegal.crm',
  appName: 'OS Legal CRM',
  webDir: '.',
  server: {
    androidScheme: 'https'
  }
};

export default config;
