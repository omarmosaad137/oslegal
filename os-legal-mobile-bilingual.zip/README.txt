OS Legal CRM Mobile Package

This package gives you two mobile routes.

1. PWA / installable mobile app
- Upload this folder to HTTPS hosting.
- Open the link on mobile.
- iPhone: Safari > Share > Add to Home Screen.
- Android: Chrome > menu > Add to Home screen / Install app.
- This gives you an app icon and full-screen mobile experience.

2. Native app wrapper with Capacitor
Requirements:
- Node.js installed.
- Android Studio for Android.
- Xcode on macOS for iOS.
- Apple Developer Program for App Store publishing.
- Google Play Console for Play Store publishing.

Commands:
npm install
npm run cap:init
npm run cap:add:android
npm run cap:sync
npm run cap:open:android

For iOS:
npm run cap:add:ios
npm run cap:sync
npm run cap:open:ios

Important:
The current app stores data locally in the device/browser. For real firm use across multiple users and devices, add secure login, backend database, encrypted file storage, permissions, audit logs, and server-side email sending.


Bilingual update:
- English/Arabic toggle added in the top bar.
- Arabic RTL layout support.
- Arabic translations for main navigation, dashboards, forms, calendar, templates, email queue, and core statuses.
- Arabic admin email/update templates added.
- Dynamic client/matter data remains in the language entered by the user.
